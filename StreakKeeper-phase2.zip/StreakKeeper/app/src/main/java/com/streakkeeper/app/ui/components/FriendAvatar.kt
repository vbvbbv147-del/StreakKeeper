package com.streakkeeper.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streakkeeper.app.data.FriendStyle
import com.streakkeeper.app.data.StickerStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun FriendAvatar(
    stickerUri: String?,
    username: String,
    modifier: Modifier = Modifier,
    avatarSize: Dp = 48.dp
) {
    val emoji = FriendStyle.emojiOf(stickerUri)
    Box(
        modifier = modifier
            .size(avatarSize)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        if (emoji != null) {
            Text(text = emoji, fontSize = (avatarSize.value * 0.5f).sp)
        } else if (FriendStyle.isImage(stickerUri)) {
            val bitmap by produceState<ImageBitmap?>(initialValue = null, stickerUri) {
                value = withContext(Dispatchers.IO) {
                    stickerUri?.let { StickerStorage.load(it) }?.asImageBitmap()
                }
            }
            bitmap?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Text(
                text = username.take(1).uppercase(),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontSize = (avatarSize.value * 0.42f).sp
            )
        }
    }
}

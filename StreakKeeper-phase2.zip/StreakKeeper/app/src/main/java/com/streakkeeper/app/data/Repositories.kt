package com.streakkeeper.app.data

import android.database.sqlite.SQLiteConstraintException
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

enum class SaveResult { OK, INVALID, DUPLICATE }

class FriendRepository(private val db: AppDatabase) {
    fun observeAll(): Flow<List<Friend>> = db.friendDao().observeAll()

    suspend fun add(rawUsername: String, stickerUri: String?): SaveResult {
        val username = UsernameRules.normalize(rawUsername)
        if (!UsernameRules.isValid(username)) return SaveResult.INVALID
        return try {
            val next = db.friendDao().maxSortOrder() + 1
            db.friendDao().insert(
                Friend(tiktokUsername = username, stickerUri = stickerUri, sortOrder = next)
            )
            SaveResult.OK
        } catch (e: SQLiteConstraintException) {
            SaveResult.DUPLICATE
        }
    }

    suspend fun update(friend: Friend, rawUsername: String, stickerUri: String?): SaveResult {
        val username = UsernameRules.normalize(rawUsername)
        if (!UsernameRules.isValid(username)) return SaveResult.INVALID
        return try {
            db.friendDao().update(friend.copy(tiktokUsername = username, stickerUri = stickerUri))
            if (friend.stickerUri != stickerUri) StickerStorage.delete(friend.stickerUri)
            SaveResult.OK
        } catch (e: SQLiteConstraintException) {
            SaveResult.DUPLICATE
        }
    }

    /** Tasks of the friend are removed by the foreign key cascade. */
    suspend fun delete(friend: Friend) {
        db.friendDao().delete(friend)
        StickerStorage.delete(friend.stickerUri)
    }
}

class TaskRepository(private val db: AppDatabase) {
    private fun today(): String = LocalDate.now().toString()

    fun observeToday(): Flow<List<TaskWithFriend>> = db.sendTaskDao().observeWithFriends(today())

    fun observePendingCount(): Flow<Int> = db.sendTaskDao().observeCount(today(), TaskStatus.PENDING)

    fun observeCompletedCount(): Flow<Int> = db.sendTaskDao().observeCount(today(), TaskStatus.COMPLETED)

    suspend fun pendingCountNow(): Int = db.sendTaskDao().countNow(today(), TaskStatus.PENDING)

    /** Creates today's task for every friend that does not have one yet. Local only; sends nothing. */
    suspend fun prepareToday(defaultMessage: String) {
        val date = today()
        val dao = db.sendTaskDao()
        val existing = dao.friendIdsForDate(date).toSet()
        val missing = db.friendDao().getAll()
            .filter { it.id !in existing }
            .map { SendTask(friendId = it.id, date = date, message = defaultMessage) }
        if (missing.isNotEmpty()) dao.insertAll(missing)
        dao.deleteOlderThan(LocalDate.now().minusDays(30).toString())
    }

    suspend fun saveMessage(taskId: Long, message: String) =
        db.sendTaskDao().updateMessage(taskId, message)

    /** Call only after the user explicitly confirmed they sent the message themselves. */
    suspend fun markCompleted(taskId: Long, message: String) =
        db.sendTaskDao().markCompleted(taskId, System.currentTimeMillis(), message)
}

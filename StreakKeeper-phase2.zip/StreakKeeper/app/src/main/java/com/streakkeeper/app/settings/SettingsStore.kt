package com.streakkeeper.app.settings

import android.content.Context
import com.streakkeeper.app.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val scheduleEnabled: Boolean,
    val hour: Int,
    val minute: Int,
    val defaultMessage: String
)

/** Small SharedPreferences-backed store exposed as a StateFlow. Default schedule: 00:00 (12:00 AM). */
class SettingsStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("streak_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun load() = AppSettings(
        scheduleEnabled = prefs.getBoolean(KEY_ENABLED, true),
        hour = prefs.getInt(KEY_HOUR, 0),
        minute = prefs.getInt(KEY_MINUTE, 0),
        defaultMessage = prefs.getString(KEY_MESSAGE, null)
            ?: context.getString(R.string.default_message)
    )

    fun update(transform: (AppSettings) -> AppSettings): AppSettings {
        val next = transform(_state.value)
        prefs.edit()
            .putBoolean(KEY_ENABLED, next.scheduleEnabled)
            .putInt(KEY_HOUR, next.hour)
            .putInt(KEY_MINUTE, next.minute)
            .putString(KEY_MESSAGE, next.defaultMessage)
            .apply()
        _state.value = next
        return next
    }

    private companion object {
        const val KEY_ENABLED = "schedule_enabled"
        const val KEY_HOUR = "schedule_hour"
        const val KEY_MINUTE = "schedule_minute"
        const val KEY_MESSAGE = "default_message"
    }
}

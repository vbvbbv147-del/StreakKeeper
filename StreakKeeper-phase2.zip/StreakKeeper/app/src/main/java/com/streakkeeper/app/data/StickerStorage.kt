package com.streakkeeper.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Copies user-picked sticker images into app-private storage (no permissions, nothing leaves the device). */
object StickerStorage {
    private const val DIR = "stickers"
    private const val MAX_PX = 256

    suspend fun import(context: Context, source: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null

            var sample = 1
            while (bounds.outWidth / sample > MAX_PX * 2 || bounds.outHeight / sample > MAX_PX * 2) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(source)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return@withContext null

            val scale = minOf(1f, MAX_PX.toFloat() / maxOf(decoded.width, decoded.height))
            val bitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * scale).toInt().coerceAtLeast(1),
                    (decoded.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                decoded
            }

            val dir = File(context.filesDir, DIR).apply { mkdirs() }
            val file = File(dir, "${UUID.randomUUID()}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Uri.fromFile(file).toString()
        } catch (e: Exception) {
            null
        }
    }

    fun load(uriString: String): Bitmap? =
        Uri.parse(uriString).path?.let { BitmapFactory.decodeFile(it) }

    /** Deletes only files inside our own stickers directory. */
    fun delete(uriString: String?) {
        if (!FriendStyle.isImage(uriString)) return
        runCatching {
            Uri.parse(uriString).path?.let { path ->
                File(path).takeIf { it.parentFile?.name == DIR }?.delete()
            }
        }
    }
}

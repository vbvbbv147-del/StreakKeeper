package com.streakkeeper.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streakkeeper.app.StreakKeeperApp
import com.streakkeeper.app.data.Friend
import com.streakkeeper.app.data.SaveResult
import com.streakkeeper.app.data.StickerStorage
import com.streakkeeper.app.data.TaskStatus
import com.streakkeeper.app.data.TaskWithFriend
import com.streakkeeper.app.settings.AppSettings
import com.streakkeeper.app.work.ScheduleManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private fun AndroidViewModel.appOf(): StreakKeeperApp = getApplication<Application>() as StreakKeeperApp

// ---------- Friends ----------

class FriendsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = appOf()

    val friends: StateFlow<List<Friend>> = app.friendRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun importSticker(uri: Uri): String? = StickerStorage.import(app, uri)

    fun discardSticker(uriString: String?) = StickerStorage.delete(uriString)

    /** Returns the result so the dialog can show validation errors; new friends get today's task right away. */
    suspend fun save(existing: Friend?, username: String, stickerUri: String?): SaveResult {
        val result = if (existing == null) {
            app.friendRepository.add(username, stickerUri)
        } else {
            app.friendRepository.update(existing, username, stickerUri)
        }
        if (result == SaveResult.OK) {
            app.taskRepository.prepareToday(app.settings.state.value.defaultMessage)
        }
        return result
    }

    fun delete(friend: Friend) {
        viewModelScope.launch { app.friendRepository.delete(friend) }
    }
}

// ---------- Dashboard ----------

data class DashboardState(
    val friendCount: Int = 0,
    val pending: Int = 0,
    val completed: Int = 0,
    val settings: AppSettings
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val app = appOf()

    val state: StateFlow<DashboardState> = combine(
        app.database.friendDao().observeCount(),
        app.taskRepository.observePendingCount(),
        app.taskRepository.observeCompletedCount(),
        app.settings.state
    ) { friends, pending, completed, settings ->
        DashboardState(friends, pending, completed, settings)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        DashboardState(settings = app.settings.state.value)
    )

    init {
        // Make sure today's tasks exist (one per friend) when the app is opened.
        viewModelScope.launch {
            app.taskRepository.prepareToday(app.settings.state.value.defaultMessage)
        }
    }
}

// ---------- Send All (sequential queue) ----------

data class SendUiState(
    val loaded: Boolean = false,
    val total: Int = 0,
    val completed: Int = 0,
    val current: TaskWithFriend? = null,
    val skippedPending: Int = 0
)

class SendViewModel(application: Application) : AndroidViewModel(application) {
    private val app = appOf()
    private val skipped = MutableStateFlow<Set<Long>>(emptySet())

    val state: StateFlow<SendUiState> = combine(app.taskRepository.observeToday(), skipped) { tasks, skippedIds ->
        val ordered = tasks.sortedWith(compareBy({ it.friend.sortOrder }, { it.friend.id }))
        val pending = ordered.filter { it.task.status == TaskStatus.PENDING }
        SendUiState(
            loaded = true,
            total = ordered.size,
            completed = ordered.size - pending.size,
            current = pending.firstOrNull { it.task.id !in skippedIds },
            skippedPending = pending.count { it.task.id in skippedIds }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SendUiState())

    init {
        viewModelScope.launch {
            app.taskRepository.prepareToday(app.settings.state.value.defaultMessage)
        }
    }

    fun saveMessage(taskId: Long, message: String) {
        viewModelScope.launch { app.taskRepository.saveMessage(taskId, message) }
    }

    /** Only called after the user pressed the confirmation button in the dialog. */
    fun confirmSent(taskId: Long, message: String) {
        viewModelScope.launch { app.taskRepository.markCompleted(taskId, message) }
    }

    fun skip(taskId: Long) {
        skipped.update { it + taskId }
    }

    fun showSkippedAgain() {
        skipped.value = emptySet()
    }
}

// ---------- Settings ----------

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = appOf()
    val settings: StateFlow<AppSettings> = app.settings.state

    private fun change(transform: (AppSettings) -> AppSettings) {
        val next = app.settings.update(transform)
        ScheduleManager.apply(app, next, replace = true)
    }

    fun setEnabled(enabled: Boolean) = change { it.copy(scheduleEnabled = enabled) }

    fun setTime(hour: Int, minute: Int) = change { it.copy(hour = hour, minute = minute) }

    fun setDefaultMessage(message: String) {
        app.settings.update { it.copy(defaultMessage = message.trim()) }
    }
}

package com.streakkeeper.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * tiktokUsername: stored WITHOUT '@', lowercase (normalize in the UI/repository layer).
 * stickerUri: persisted content/file URI string, null = no sticker assigned yet.
 * sortOrder: position in the sending queue (ascending).
 */
@Entity(
    tableName = "friends",
    indices = [Index(value = ["tiktokUsername"], unique = true)]
)
data class Friend(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tiktokUsername: String,
    val stickerUri: String? = null,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

package com.streakkeeper.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.streakkeeper.app.ui.navigation.StreakKeeperRoot
import com.streakkeeper.app.ui.theme.StreakKeeperTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StreakKeeperTheme {
                StreakKeeperRoot()
            }
        }
    }
}

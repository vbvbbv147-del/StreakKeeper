package com.streakkeeper.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface SendTaskDao {
    @Transaction
    @Query("SELECT * FROM send_tasks WHERE date = :date")
    fun observeWithFriends(date: String): Flow<List<TaskWithFriend>>

    @Query("SELECT COUNT(*) FROM send_tasks WHERE date = :date AND status = :status")
    fun observeCount(date: String, status: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM send_tasks WHERE date = :date AND status = :status")
    suspend fun countNow(date: String, status: String): Int

    @Query("SELECT friendId FROM send_tasks WHERE date = :date")
    suspend fun friendIdsForDate(date: String): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(tasks: List<SendTask>)

    @Query("UPDATE send_tasks SET message = :message WHERE id = :id AND status = 'PENDING'")
    suspend fun updateMessage(id: Long, message: String)

    @Query("UPDATE send_tasks SET status = 'COMPLETED', completedAt = :completedAt, message = :message WHERE id = :id")
    suspend fun markCompleted(id: Long, completedAt: Long, message: String)

    @Query("DELETE FROM send_tasks WHERE date < :date")
    suspend fun deleteOlderThan(date: String)
}

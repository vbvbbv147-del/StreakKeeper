package com.streakkeeper.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7CB7FF),
    onPrimary = Color(0xFF00315C),
    primaryContainer = Color(0xFF0B4A85),
    onPrimaryContainer = Color(0xFFD3E4FF),
    secondary = Color(0xFFB9C8DA),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE3E2E6),
    surface = Color(0xFF0F1115),
    onSurface = Color(0xFFE3E2E6),
    surfaceVariant = Color(0xFF1B1F27),
    onSurfaceVariant = Color(0xFFC3C6CF)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0B5FA8),
    background = Color(0xFFF8F9FF),
    surface = Color(0xFFF8F9FF)
)

/**
 * Dark-first: dark is the default regardless of system setting.
 * Pass darkTheme = isSystemInDarkTheme() later if a theme toggle is added.
 * RTL is forced because Arabic is the default language.
 */
@Composable
fun StreakKeeperTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            content = content
        )
    }
}

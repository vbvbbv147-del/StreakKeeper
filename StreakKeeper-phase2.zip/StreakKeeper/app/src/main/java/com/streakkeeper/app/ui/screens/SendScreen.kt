package com.streakkeeper.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.streakkeeper.app.R
import com.streakkeeper.app.data.TaskWithFriend
import com.streakkeeper.app.ui.components.FriendAvatar
import com.streakkeeper.app.ui.viewmodel.SendViewModel

@Composable
fun SendScreen(onBack: () -> Unit, viewModel: SendViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.common_back))
            }
            Text(
                text = stringResource(R.string.send_title),
                style = MaterialTheme.typography.headlineMedium
            )
        }

        val current = state.current
        when {
            !state.loaded -> Unit
            state.total == 0 -> Text(
                text = stringResource(R.string.send_no_friends),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            else -> {
                Text(
                    text = stringResource(R.string.send_progress, state.completed, state.total),
                    style = MaterialTheme.typography.titleMedium
                )
                LinearProgressIndicator(
                    progress = { state.completed.toFloat() / state.total.toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )
                if (current != null) {
                    // key() resets the editable draft whenever the queue moves to the next friend.
                    androidx.compose.runtime.key(current.task.id) {
                        TaskCard(
                            item = current,
                            onSaveMessage = { viewModel.saveMessage(current.task.id, it) },
                            onConfirmSent = { viewModel.confirmSent(current.task.id, it) },
                            onSkip = { viewModel.skip(current.task.id) }
                        )
                    }
                } else if (state.skippedPending > 0) {
                    Text(
                        text = stringResource(R.string.send_skipped_left, state.skippedPending),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Button(onClick = viewModel::showSkippedAgain, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.send_show_skipped))
                    }
                } else {
                    Text(
                        text = stringResource(R.string.send_all_done),
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun TaskCard(
    item: TaskWithFriend,
    onSaveMessage: (String) -> Unit,
    onConfirmSent: (String) -> Unit,
    onSkip: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var message by remember { mutableStateOf(item.task.message) }
    var confirming by remember { mutableStateOf(false) }
    val username = item.friend.tiktokUsername

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FriendAvatar(stickerUri = item.friend.stickerUri, username = username, avatarSize = 56.dp)
            Text(text = "@$username", style = MaterialTheme.typography.titleLarge)
        }
        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text(stringResource(R.string.send_message_label)) },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    onSaveMessage(message)
                    clipboard.setText(AnnotatedString(message))
                    Toast.makeText(context, R.string.send_copied, Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.send_copy)) }
            OutlinedButton(
                onClick = {
                    onSaveMessage(message)
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@$username"))
                    try {
                        context.startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, R.string.send_open_failed, Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.send_open_profile)) }
        }
        Text(
            text = stringResource(R.string.send_manual_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = { confirming = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.send_mark_done)) }
        TextButton(onClick = {
            onSaveMessage(message)
            onSkip()
        }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.send_skip)) }
    }

    if (confirming) {
        AlertDialog(
            onDismissRequest = { confirming = false },
            title = { Text(stringResource(R.string.send_confirm_title)) },
            text = { Text(stringResource(R.string.send_confirm_message, username)) },
            confirmButton = {
                TextButton(onClick = {
                    confirming = false
                    onConfirmSent(message)
                }) { Text(stringResource(R.string.send_confirm_yes)) }
            },
            dismissButton = {
                TextButton(onClick = { confirming = false }) { Text(stringResource(R.string.send_confirm_no)) }
            }
        )
    }
}

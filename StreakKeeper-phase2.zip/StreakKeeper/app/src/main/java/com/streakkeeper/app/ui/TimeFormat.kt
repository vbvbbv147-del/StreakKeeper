package com.streakkeeper.app.ui

/** 12-hour clock with Arabic AM/PM markers, e.g. 00:00 -> "12:00 ص". */
fun formatTime(hour: Int, minute: Int): String {
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    val suffix = if (hour < 12) "ص" else "م"
    return "%d:%02d %s".format(h12, minute, suffix)
}

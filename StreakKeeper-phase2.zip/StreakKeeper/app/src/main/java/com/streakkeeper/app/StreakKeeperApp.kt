package com.streakkeeper.app

import android.app.Application
import com.streakkeeper.app.data.AppDatabase
import com.streakkeeper.app.data.FriendRepository
import com.streakkeeper.app.data.TaskRepository
import com.streakkeeper.app.settings.SettingsStore
import com.streakkeeper.app.work.NotificationHelper
import com.streakkeeper.app.work.ScheduleManager

class StreakKeeperApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.get(this) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
    val friendRepository: FriendRepository by lazy { FriendRepository(database) }
    val taskRepository: TaskRepository by lazy { TaskRepository(database) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannel(this)
        ScheduleManager.apply(this, settings.state.value, replace = false)
    }
}

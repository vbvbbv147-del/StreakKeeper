package com.streakkeeper.app.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.streakkeeper.app.StreakKeeperApp

/** Prepares today's local tasks and reminds the user. It never contacts TikTok and never sends anything. */
class DailySendWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as StreakKeeperApp
        val settings = app.settings.state.value
        if (!settings.scheduleEnabled) return Result.success()

        app.taskRepository.prepareToday(settings.defaultMessage)
        val pending = app.taskRepository.pendingCountNow()
        if (pending > 0) NotificationHelper.notifyPending(applicationContext, pending)
        return Result.success()
    }
}

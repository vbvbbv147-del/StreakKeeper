package com.streakkeeper.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.streakkeeper.app.R
import com.streakkeeper.app.data.Friend
import com.streakkeeper.app.data.FriendStyle
import com.streakkeeper.app.data.SaveResult
import com.streakkeeper.app.ui.components.FriendAvatar
import com.streakkeeper.app.ui.viewmodel.FriendsViewModel
import kotlinx.coroutines.launch

private val QuickEmojis = listOf("🔥", "⭐", "💙", "😎", "🎯", "🚀", "🌟", "❤️", "😂", "👑")

@Composable
fun FriendsScreen(viewModel: FriendsViewModel = viewModel()) {
    val friends by viewModel.friends.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Friend?>(null) }
    var deleting by remember { mutableStateOf<Friend?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = stringResource(R.string.friends_title),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 20.dp, bottom = 12.dp)
            )
            if (friends.isEmpty()) {
                Text(
                    text = stringResource(R.string.friends_empty),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(friends, key = { it.id }) { friend ->
                        FriendRow(
                            friend = friend,
                            onEdit = { editing = friend },
                            onDelete = { deleting = friend }
                        )
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text(stringResource(R.string.friends_add)) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        )
    }

    if (showAdd) {
        FriendEditorDialog(
            initial = null,
            viewModel = viewModel,
            onDismiss = { showAdd = false }
        )
    }
    editing?.let { friend ->
        FriendEditorDialog(
            initial = friend,
            viewModel = viewModel,
            onDismiss = { editing = null }
        )
    }
    deleting?.let { friend ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.friend_delete_title)) },
            text = { Text(stringResource(R.string.friend_delete_message, friend.tiktokUsername)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.delete(friend)
                    deleting = null
                }) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.common_cancel)) }
            }
        )
    }
}

@Composable
private fun FriendRow(friend: Friend, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FriendAvatar(stickerUri = friend.stickerUri, username = friend.tiktokUsername)
            Text(
                text = "@${friend.tiktokUsername}",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.common_edit))
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.common_delete))
            }
        }
    }
}

@Composable
private fun FriendEditorDialog(
    initial: Friend?,
    viewModel: FriendsViewModel,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf(initial?.tiktokUsername ?: "") }
    var style by remember { mutableStateOf(initial?.stickerUri) }
    var emojiInput by remember { mutableStateOf(FriendStyle.emojiOf(initial?.stickerUri) ?: "") }
    var error by remember { mutableStateOf<Int?>(null) }
    var saving by remember { mutableStateOf(false) }
    // Image imported during this dialog session but not yet saved (deleted if the dialog is cancelled/replaced).
    var importedThisSession by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = viewModel.importSticker(uri)
                if (imported == null) {
                    error = R.string.friend_image_failed
                } else {
                    importedThisSession?.let { viewModel.discardSticker(it) }
                    importedThisSession = imported
                    style = imported
                    emojiInput = ""
                    error = null
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = {
            if (!saving) {
                importedThisSession?.let { viewModel.discardSticker(it) }
                onDismiss()
            }
        },
        title = {
            Text(
                stringResource(
                    if (initial == null) R.string.friend_dialog_add_title else R.string.friend_dialog_edit_title
                )
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FriendAvatar(stickerUri = style, username = username.ifBlank { "?" }, avatarSize = 56.dp)
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it; error = null },
                        label = { Text(stringResource(R.string.friend_username)) },
                        prefix = { Text("@") },
                        singleLine = true,
                        isError = error == R.string.friend_username_invalid || error == R.string.friend_username_duplicate,
                        modifier = Modifier.weight(1f)
                    )
                }
                error?.let {
                    Text(
                        text = stringResource(it),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = emojiInput,
                    onValueChange = { input ->
                        val first = FriendStyle.firstGrapheme(input)
                        emojiInput = first
                        if (first.isNotEmpty()) {
                            importedThisSession?.let { viewModel.discardSticker(it) }
                            importedThisSession = null
                            style = FriendStyle.fromEmoji(first)
                        }
                    },
                    label = { Text(stringResource(R.string.friend_emoji)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(QuickEmojis) { e ->
                        Text(
                            text = e,
                            fontSize = 26.sp,
                            modifier = Modifier
                                .clickable {
                                    importedThisSession?.let { viewModel.discardSticker(it) }
                                    importedThisSession = null
                                    emojiInput = e
                                    style = FriendStyle.fromEmoji(e)
                                }
                                .padding(4.dp)
                        )
                    }
                }
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.friend_pick_image)) }
                if (style != null) {
                    TextButton(
                        onClick = {
                            importedThisSession?.let { viewModel.discardSticker(it) }
                            importedThisSession = null
                            style = null
                            emojiInput = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.friend_remove_style)) }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !saving && username.isNotBlank(),
                onClick = {
                    saving = true
                    scope.launch {
                        when (viewModel.save(initial, username, style)) {
                            SaveResult.OK -> {
                                importedThisSession = null
                                onDismiss()
                            }
                            SaveResult.INVALID -> {
                                error = R.string.friend_username_invalid
                                saving = false
                            }
                            SaveResult.DUPLICATE -> {
                                error = R.string.friend_username_duplicate
                                saving = false
                            }
                        }
                    }
                }
            ) { Text(stringResource(R.string.common_save)) }
        },
        dismissButton = {
            TextButton(
                enabled = !saving,
                onClick = {
                    importedThisSession?.let { viewModel.discardSticker(it) }
                    onDismiss()
                }
            ) { Text(stringResource(R.string.common_cancel)) }
        }
    )
}

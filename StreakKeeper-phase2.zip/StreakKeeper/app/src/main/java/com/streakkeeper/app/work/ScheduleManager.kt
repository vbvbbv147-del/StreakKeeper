package com.streakkeeper.app.work

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.streakkeeper.app.settings.AppSettings
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * Schedules one WorkManager periodic job (24h) whose first run is delayed until the chosen time of day.
 * WorkManager timing is inexact: Android may delay the job (battery optimization, Doze), so the app never
 * promises an exact execution time. The job only prepares local tasks and posts a reminder.
 */
object ScheduleManager {
    const val UNIQUE_NAME = "daily_prepare"

    fun nextRun(now: ZonedDateTime, hour: Int, minute: Int): ZonedDateTime {
        val candidate = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        return if (candidate.isAfter(now)) candidate else candidate.plusDays(1)
    }

    /** replace = true when the user changed the settings; false on app start (keeps the existing job). */
    fun apply(context: Context, settings: AppSettings, replace: Boolean) {
        val workManager = WorkManager.getInstance(context.applicationContext)
        if (!settings.scheduleEnabled) {
            workManager.cancelUniqueWork(UNIQUE_NAME)
            return
        }
        val now = ZonedDateTime.now()
        val delayMs = Duration.between(now, nextRun(now, settings.hour, settings.minute)).toMillis()
        val request = PeriodicWorkRequestBuilder<DailySendWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_NAME,
            if (replace) ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE else ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}

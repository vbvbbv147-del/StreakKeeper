package com.streakkeeper.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Friend::class, SendTask::class], version = 2, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun friendDao(): FriendDao
    abstract fun sendTaskDao(): SendTaskDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        /** v1 -> v2: adds send_tasks. The friends table is not touched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `send_tasks` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`friendId` INTEGER NOT NULL, " +
                        "`date` TEXT NOT NULL, " +
                        "`message` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`completedAt` INTEGER, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`friendId`) REFERENCES `friends`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_send_tasks_friendId_date` " +
                        "ON `send_tasks` (`friendId`, `date`)"
                )
            }
        }

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "streak_keeper.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { instance = it }
            }
    }
}

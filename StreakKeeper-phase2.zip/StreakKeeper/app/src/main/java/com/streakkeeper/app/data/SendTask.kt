package com.streakkeeper.app.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

object TaskStatus {
    const val PENDING = "PENDING"
    const val COMPLETED = "COMPLETED"
}

/**
 * One sending task per friend per day. `date` is an ISO local date (yyyy-MM-dd).
 * A task becomes COMPLETED only after the user explicitly confirms they sent the message themselves.
 */
@Entity(
    tableName = "send_tasks",
    foreignKeys = [
        ForeignKey(
            entity = Friend::class,
            parentColumns = ["id"],
            childColumns = ["friendId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["friendId", "date"], unique = true)]
)
data class SendTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val friendId: Long,
    val date: String,
    val message: String,
    val status: String = TaskStatus.PENDING,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class TaskWithFriend(
    @Embedded val task: SendTask,
    @Relation(parentColumn = "friendId", entityColumn = "id")
    val friend: Friend
)

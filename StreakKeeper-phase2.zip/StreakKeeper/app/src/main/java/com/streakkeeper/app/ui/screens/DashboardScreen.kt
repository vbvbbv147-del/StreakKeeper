package com.streakkeeper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.streakkeeper.app.R
import com.streakkeeper.app.ui.formatTime
import com.streakkeeper.app.ui.viewmodel.DashboardViewModel

@Composable
fun DashboardScreen(onSendAll: () -> Unit, viewModel: DashboardViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = stringResource(R.string.dashboard_title),
            style = MaterialTheme.typography.headlineMedium
        )
        StatCard(stringResource(R.string.dashboard_friends_count, state.friendCount), Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                stringResource(R.string.dashboard_pending, state.pending),
                Modifier.weight(1f)
            )
            StatCard(
                stringResource(R.string.dashboard_completed, state.completed),
                Modifier.weight(1f)
            )
        }
        StatCard(
            text = if (state.settings.scheduleEnabled) {
                stringResource(
                    R.string.dashboard_schedule_on,
                    formatTime(state.settings.hour, state.settings.minute)
                )
            } else {
                stringResource(R.string.dashboard_schedule_off)
            },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = onSendAll,
            enabled = state.friendCount > 0,
            modifier = Modifier
                .fillMaxWidth()
                .height(96.dp)
        ) {
            Text(
                text = stringResource(R.string.send_all),
                style = MaterialTheme.typography.headlineSmall
            )
        }
        if (state.friendCount == 0) {
            Text(
                text = stringResource(R.string.send_all_need_friends),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StatCard(text: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(20.dp)
        )
    }
}

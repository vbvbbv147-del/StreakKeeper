package com.streakkeeper.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FriendDao {
    @Query("SELECT * FROM friends ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<Friend>>

    @Query("SELECT * FROM friends ORDER BY sortOrder ASC, id ASC")
    suspend fun getAll(): List<Friend>

    @Query("SELECT COUNT(*) FROM friends")
    fun observeCount(): Flow<Int>

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM friends")
    suspend fun maxSortOrder(): Int

    @Query("SELECT * FROM friends WHERE id = :id")
    suspend fun getById(id: Long): Friend?

    @Insert
    suspend fun insert(friend: Friend): Long

    @Update
    suspend fun update(friend: Friend)

    @Delete
    suspend fun delete(friend: Friend)
}

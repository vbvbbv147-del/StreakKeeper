package com.streakkeeper.app.data

import java.text.BreakIterator

/**
 * The Friend entity is intentionally unchanged (database compatibility), so the friend's look is
 * encoded in `stickerUri`:
 *   "emoji:<emoji>"        -> custom emoji
 *   "file:///.../x.png"    -> sticker image stored in the app's private storage
 *   null                   -> default avatar (first letter)
 */
object FriendStyle {
    private const val EMOJI_PREFIX = "emoji:"

    fun fromEmoji(emoji: String): String? {
        val e = firstGrapheme(emoji)
        return if (e.isEmpty()) null else EMOJI_PREFIX + e
    }

    fun emojiOf(stickerUri: String?): String? =
        stickerUri
            ?.takeIf { it.startsWith(EMOJI_PREFIX) }
            ?.removePrefix(EMOJI_PREFIX)
            ?.takeIf { it.isNotBlank() }

    fun isImage(stickerUri: String?): Boolean = stickerUri?.startsWith("file:") == true

    fun firstGrapheme(input: String): String {
        val s = input.trim()
        if (s.isEmpty()) return ""
        val it = BreakIterator.getCharacterInstance()
        it.setText(s)
        val end = it.next()
        return if (end == BreakIterator.DONE) s else s.substring(0, end)
    }
}

object UsernameRules {
    private val pattern = Regex("^[a-z0-9._]{2,24}$")

    fun normalize(raw: String): String = raw.trim().removePrefix("@").trim().lowercase()

    fun isValid(username: String): Boolean = pattern.matches(username) && !username.endsWith(".")
}

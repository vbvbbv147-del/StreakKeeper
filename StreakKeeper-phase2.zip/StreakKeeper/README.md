# Streak Keeper — Phase 2

Kotlin + Jetpack Compose + Material 3 + Room + WorkManager. Package: `com.streakkeeper.app`.
Arabic default (forced RTL), dark-first. Phase 1 = architecture, Gradle, theme, navigation, Room `Friend` entity.

## Requirements

- JDK 17
- Android SDK with platform 35 (Android Studio Ladybug or newer recommended)
- minSdk 26, compileSdk/targetSdk 35
- Versions: AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Gradle 8.9, Compose BOM 2024.12.01, Room 2.6.1, WorkManager 2.10.0

## Build

The Gradle wrapper jar and `gradlew` scripts are not included. Generate them once:

```
gradle wrapper --gradle-version 8.9
```

Or open the project in Android Studio, which generates them on sync.

Then:

```
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Install on a connected device or emulator:

```
./gradlew installDebug
```

If the SDK is not found, create `local.properties` with `sdk.dir=/path/to/Android/Sdk`.

## Structure

```
app/src/main/java/com/streakkeeper/app/
  StreakKeeperApp.kt        Application, lazy Room database
  MainActivity.kt           edge-to-edge, theme, root composable
  data/                     Friend, FriendDao, AppDatabase (v1, schema exported)
  ui/theme/Theme.kt         dark-first Material 3 theme, forced RTL
  ui/navigation/            Screen, StreakKeeperRoot (bottom nav)
  ui/screens/               Dashboard, Friends, Settings
```

## Phase 2 features

- Friends: add / edit / delete (Room). Username is stored without `@`, lowercase. The look (emoji or
  sticker image) is encoded in `Friend.stickerUri` so the `friends` table is unchanged:
  `emoji:<emoji>`, or a `file://` URI of an image copied to app-private storage, or null.
- Send All: one `SendTask` per friend per day (DB v2, `MIGRATION_1_2`), processed one at a time. The user edits/copies
  the message, opens the public profile (`https://www.tiktok.com/@user`), sends manually inside TikTok, then
  confirms in a dialog. Only that confirmation marks the task COMPLETED. Nothing is ever sent automatically.
- Scheduling: default 12:00 AM, toggle and time in Settings. A WorkManager periodic job prepares today's tasks and
  posts a reminder. Timing is approximate (Android may delay background work); there is no exact-alarm use.
- Dashboard: friend count, pending/completed tasks for today, scheduling status.
- Auto Reply: shown as unavailable (TikTok has no supported official messaging interface).

## Build

No Gradle wrapper jar is committed. CI (`.github/workflows/android.yml`) uses a pinned Gradle 8.9 and uploads the debug APK.
Room schemas are exported to `app/schemas/` on the first build; commit them afterwards.
